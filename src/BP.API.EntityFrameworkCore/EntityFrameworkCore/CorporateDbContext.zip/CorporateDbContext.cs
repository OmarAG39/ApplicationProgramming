﻿using Abp.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Nova.Corporate.Entity;


namespace Nova.Corporate.EntityFrameworkCore
{
    public class CorporateDbContext : AbpDbContext
    {
        //Add DbSet properties for your entities...
        public DbSet<AuditLog> AuditLog { get; set; }

        public DbSet<AuditDescription> AuditDescription { get; set; }
        public DbSet<Client> Client { get; set; }
        public DbSet<Policy> Policy { get; set; }
        public DbSet<Catalogue> Catalogue { get; set; }
        public DbSet<CatalogueDetail> CatalogueDetail { get; set; }

        public CorporateDbContext(DbContextOptions<CorporateDbContext> options) 
            : base(options)
        {

        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            // para indexar 1 columnas
            modelBuilder.Entity<Client>()
                           .HasIndex(p => new { p.Id });
            // para indexar 2 columnas
           // modelBuilder.Entity <Policy >()
             //               .HasIndex(p => new { p.Id, p.PolicyNumber  });

            // para no permitir nullos y es unico
            //modelBuilder.Entity<Client>().HasIndex(b => b.Id).IsUnique().HasFilter(null);
            

        }
    }
}
